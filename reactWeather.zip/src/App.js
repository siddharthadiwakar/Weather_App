import react from "react";
import Tempapp from "./components/Tempapp";
import './App.css';

function App() {
  return (
   <Tempapp />
  );
}

export default App;
